function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: "/", script: "gen.js"},
    ]);
}